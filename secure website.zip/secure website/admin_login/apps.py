from django.apps import AppConfig


class AdminLoginConfig(AppConfig):
    name = 'admin_login'
