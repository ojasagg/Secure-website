from django.apps import AppConfig


class CustLoginConfig(AppConfig):
    name = 'cust_login'
