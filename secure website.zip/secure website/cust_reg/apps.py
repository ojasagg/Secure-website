from django.apps import AppConfig


class CustRegConfig(AppConfig):
    name = 'cust_reg'
