from django.apps import AppConfig


class EmpLoginConfig(AppConfig):
    name = 'emp_login'
