from django.apps import AppConfig


class EmpRegConfig(AppConfig):
    name = 'emp_reg'
