from django.apps import AppConfig


class ForgotpswdConfig(AppConfig):
    name = 'forgotpswd'
