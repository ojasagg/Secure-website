from django.apps import AppConfig


class LoggedinConfig(AppConfig):
    name = 'loggedin'
