from django.apps import AppConfig


class LogoutConfig(AppConfig):
    name = 'logout'
