from django.apps import AppConfig


class ManagerLoginConfig(AppConfig):
    name = 'manager_login'
