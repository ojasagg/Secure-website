from django.apps import AppConfig


class MerchLoginConfig(AppConfig):
    name = 'merch_login'
