from django.apps import AppConfig


class MerchRegConfig(AppConfig):
    name = 'merch_reg'
